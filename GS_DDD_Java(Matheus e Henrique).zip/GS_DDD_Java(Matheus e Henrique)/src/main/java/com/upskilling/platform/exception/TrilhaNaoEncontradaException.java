package com.upskilling.platform.exception;

public class TrilhaNaoEncontradaException extends RuntimeException {
    public TrilhaNaoEncontradaException(String message) {
        super(message);
    }
}