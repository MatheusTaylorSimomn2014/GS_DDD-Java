// controller/TrilhaController.java
package com.upskilling.platform.controller;

import com.upskilling.platform.model.Trilha;
import com.upskilling.platform.service.TrilhaService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/trilhas")
public class TrilhaController {

    @Autowired
    private TrilhaService trilhaService;

    @GetMapping
    public List<Trilha> listarTodos() {
        return trilhaService.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Trilha> buscarPorId(@PathVariable Long id) {
        Optional<Trilha> trilha = trilhaService.findById(id);
        return trilha.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Trilha> criar(@Valid @RequestBody Trilha trilha) {
        Trilha novaTrilha = trilhaService.save(trilha);
        return ResponseEntity.status(HttpStatus.CREATED).body(novaTrilha);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Trilha> atualizar(@PathVariable Long id, @Valid @RequestBody Trilha trilhaDetails) {
        try {
            Trilha trilhaAtualizada = trilhaService.update(id, trilhaDetails);
            return ResponseEntity.ok(trilhaAtualizada);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> remover(@PathVariable Long id) {
        try {
            trilhaService.delete(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/nivel/{nivel}")
    public List<Trilha> buscarPorNivel(@PathVariable String nivel) {
        return trilhaService.findByNivel(nivel);
    }
}