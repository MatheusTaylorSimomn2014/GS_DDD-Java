package com.upskilling.platform;

import org.springframework.boot.SpringApplication;
import import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UpskillingPlatformApplication {
    public static void main(String[] args) {
        SpringApplication.run(UpskillingPlatformApplication.class, args);
    }
}