package com.upskilling.platform.service;

import com.upskilling.platform.model.Trilha;
import com.upskilling.platform.repository.TrilhaRepository;
import com.upskilling.platform.exception.TrilhaNaoEncontradaException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TrilhaService {

    @Autowired
    private TrilhaRepository trilhaRepository;

    public List<Trilha> findAll() {
        return trilhaRepository.findAll();
    }

    public Optional<Trilha> findById(Long id) {
        return trilhaRepository.findById(id);
    }

    public Trilha save(Trilha trilha) {
        return trilhaRepository.save(trilha);
    }

    public Trilha update(Long id, Trilha trilhaDetails) {
        Trilha trilha = trilhaRepository.findById(id)
                .orElseThrow(() -> new TrilhaNaoEncontradaException("Trilha não encontrada com id: " + id));

        trilha.setNome(trilhaDetails.getNome());
        trilha.setDescricao(trilhaDetails.getDescricao());
        trilha.setNivel(trilhaDetails.getNivel());
        trilha.setCargaHoraria(trilhaDetails.getCargaHoraria());
        trilha.setFocoPrincipal(trilhaDetails.getFocoPrincipal());

        return trilhaRepository.save(trilha);
    }

    public void delete(Long id) {
        Trilha trilha = trilhaRepository.findById(id)
                .orElseThrow(() -> new TrilhaNaoEncontradaException("Trilha não encontrada com id: " + id));
        trilhaRepository.delete(trilha);
    }

    public List<Trilha> findByNivel(String nivel) {
        return trilhaRepository.findByNivel(nivel);
    }
}