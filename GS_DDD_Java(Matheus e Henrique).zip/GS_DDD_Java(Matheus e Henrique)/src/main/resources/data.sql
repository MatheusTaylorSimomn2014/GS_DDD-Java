INSERT INTO usuarios (nome, email, area_atuacao, nivel_carreira, data_cadastro) VALUES
('João Silva', 'joao.silva@email.com', 'Tecnologia', 'Pleno', '2024-01-15'),
('Maria Souza', 'maria.souza@email.com', 'Marketing', 'Senior', '2024-02-20'),
('Carlos Lima', 'carlos.lima@email.com', 'Financeiro', 'Junior', '2024-03-10');

INSERT INTO trilhas (nome, descricao, nivel, carga_horaria, foco_principal) VALUES
('IA para Iniciantes', 'Introdução à Inteligência Artificial e Machine Learning', 'INICIANTE', 40, 'IA'),
('Data Science Intermediário', 'Conceitos avançados de Data Science e Analytics', 'INTERMEDIARIO', 60, 'Dados'),
('Soft Skills para Liderança', 'Desenvolvimento de habilidades interpessoais para gestores', 'AVANCADO', 30, 'Soft Skills'),
('Desenvolvimento Web Full Stack', 'Curso completo de desenvolvimento web moderno', 'INICIANTE', 80, 'Programação'),
('Cloud Computing AWS', 'Fundamentos e práticas em computação em nuvem', 'INTERMEDIARIO', 50, 'Cloud');